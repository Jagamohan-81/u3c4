const express = require("express")

const router = express.Router();
const todos = require("../models/todo.model");
const authenticate = require("../middlewares/authenticate");
router.post("", authenticate, async (req, res) => {

    req.body.user_id = req.userID;
    try{
        const todo = await Todo.create(req.body)
        return res.status(200).send(todo)
    }
    catch(err){
        return res.status(401).send({message : err.message})
    }
 
})

router.get("", async (req, res) => {
    try{
        const todo = await Todo.find()
        return res.status(200).send(todo)
    }
    catch(err){
        return res.status(401).send({message : err.message})
    }
});
router.get("/todos/:id", authenticate, async (req, res) => {
    req.body.user_id = req.userID;
    try{
        const todo = await Todo.findOne({id:req.body.params.id})
        return res.status(200).send(todo)
    }
    catch(err){
        return res.status(401).send({message : err.message})
    }
});
router.patch("/todos/:id", authenticate, async (req, res) => {
    req.body.user_id = req.userID;
    try{
        const todo = await Todo.findOneAndUpdate(req.params.id,{$set:title},{new:true});
        return res.status(200).send(todo)
    }
    catch(err){
        return res.status(401).send({message : err.message})
    }
});
router.delete("/todos/:id", authenticate, async (req, res) => {
    req.body.user_id = req.userID;
    try{
        const todo = await Todo.findOneAndDelete(req.params.id);
        return res.status(200).send(todo)
    }
    catch(err){
        return res.status(401).send({message : err.message})
    }
});


module.exports = router;