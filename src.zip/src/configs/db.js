const mongoose = require("mongoose");

module.exports = () => {
    return mongoose.connect("mongodb://localhost/217017");
    //using local ncz some problem in my atlas.
};